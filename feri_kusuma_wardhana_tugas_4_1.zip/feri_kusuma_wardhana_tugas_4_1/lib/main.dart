/*
Nama : Feri Kusuma Wardhana
grup : 1b
*/
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Food Catalog',
      home: KatalogMakananFeri(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class KatalogMakananFeri extends StatefulWidget {
  const KatalogMakananFeri({Key? key});

  @override
  State<KatalogMakananFeri> createState() => _KatalogMakananState();
}

class _KatalogMakananState extends State<KatalogMakananFeri> {
  String pilihanKategori = 'All';

  void kategoriPilihan(String kategori) {
    setState(() {
      pilihanKategori = kategori;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Text(
              'FOOD',
              style: GoogleFonts.poppins(
                fontSize: 40,
                fontWeight: FontWeight.bold,
                color: const Color.fromARGB(255, 44, 192, 7),
              ),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Search',
                  border: OutlineInputBorder(),
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                  prefixIcon: Icon(Icons.search),
                ),
              ),
            ),
          ],
        ),
      ),
      body: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.only(left: 12, right: 12, bottom: 12),
            sliver: SliverList(
              delegate: SliverChildListDelegate(
                [
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Katalog Resep Makanan',
                        style: GoogleFonts.roboto(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        onPressed: () {},
                        icon: const Icon(Icons.settings),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 40,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: 5,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(right: 4.0),
                          child: _buildKategoriItem(index),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
          _buildResepGrid(),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        backgroundColor: const Color.fromARGB(255, 47, 228, 71),
        child: const Icon(Icons.add),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }

  Widget _buildKategoriItem(int index) {
    List<String> kategoris = ['All', 'Makanan', 'Minuman', 'Kuah', 'Goreng'];
    List<IconData> icons = [
      Icons.all_inclusive,
      Icons.fastfood,
      Icons.local_drink,
      Icons.rice_bowl_rounded,
      Icons.food_bank
    ];

    return GestureDetector(
      onTap: () {
        kategoriPilihan(kategoris[index]);
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 2),
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(20),
          color: kategoris[index] == pilihanKategori
              ? const Color.fromARGB(255, 43, 221, 58)
              : Colors.white,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icons[index]),
            const SizedBox(width: 5),
            Text(
              kategoris[index],
              style: GoogleFonts.roboto(
                fontSize: 16,
                color: kategoris[index] == pilihanKategori
                    ? const Color.fromARGB(255, 255, 254, 254)
                    : Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResepGrid() {
    List<String> judul = [
      'Apple Cake',
      'Burger',
      'Ramen Udang',
      'Karage',
      'Takoyaki'
    ];
    List<String> gambar = [
      'assets/cake.jpg',
      'assets/burger.jpg',
      'assets/ramen.jpg',
      'assets/karage.jpg',
      'assets/takoyaki.jpeg'
    ];
    List<String> waktu = ['90 min', '30 min', '40 min', '15 min', '25 min'];
    List<String> kategoris = [
      'Makanan',
      'Makanan',
      'Kuah',
      'Makanan',
      'Makanan'
    ];

    List<Widget> filteredCards = [];
    for (int i = 0; i < judul.length; i++) {
      if (pilihanKategori == 'All' || kategoris[i] == pilihanKategori) {
        filteredCards.add(_buildRecipeCard(i, judul, gambar, waktu, kategoris));
      }
    }

    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      sliver: SliverGrid(
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 300.0,
          mainAxisSpacing: 10.0,
          crossAxisSpacing: 10.0,
          childAspectRatio: 0.75,
        ),
        delegate: SliverChildListDelegate(filteredCards),
      ),
    );
  }

  Widget _buildRecipeCard(int index, List<String> judul, List<String> gambar,
      List<String> waktu, List<String> kategoris) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.grey),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
            child: Image.asset(
              gambar[index],
              height: 120,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              judul[index],
              style:
                  GoogleFonts.roboto(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 5),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.timer),
              const SizedBox(width: 5),
              Text(waktu[index]),
              const SizedBox(width: 10),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.grey),
                  color: const Color.fromARGB(255, 51, 180, 11),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: Text(
                  kategoris[index],
                  style: GoogleFonts.roboto(
                    fontSize: 14,
                    color: const Color.fromARGB(255, 255, 255, 255),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}
